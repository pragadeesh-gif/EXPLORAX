let DATA=null, currentView='command', runTimer=null;
const $=id=>document.getElementById(id);
async function api(path,method='GET',body){
  const opt={method,headers:{}}; if(body){opt.headers['Content-Type']='application/json';opt.body=JSON.stringify(body)}
  const r=await fetch(path,opt); let j={}; try{j=await r.json()}catch(e){}
  if(r.status===401){showLogin();throw new Error('Unauthorized')}
  if(!r.ok) throw new Error(j.error||('HTTP '+r.status)); return j;
}
async function login(){
  try{const j=await api('/api/login','POST',{username:$('loginUser').value,password:$('loginPass').value}); $('login').classList.add('hidden'); $('userBadge').textContent=`${j.user.role} · ${j.user.username}`; await refresh();}
  catch(e){$('loginMsg').textContent=e.message}
}
async function logout(){await fetch('/api/logout',{method:'POST'});showLogin()}
function showLogin(){$('login').classList.remove('hidden')}
async function init(){
  document.querySelectorAll('#nav button').forEach(b=>b.onclick=()=>showView(b.dataset.view));
  const me=await fetch('/api/me').then(r=>r.json()).catch(()=>({}));
  if(me.user){$('login').classList.add('hidden');$('userBadge').textContent=`${me.user.role} · ${me.user.username}`;await refresh()}else showLogin();
}
function showView(v){currentView=v;document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));$('view-'+v).classList.add('active');document.querySelectorAll('#nav button').forEach(x=>x.classList.toggle('active',x.dataset.view===v));}
async function refresh(){DATA=await api('/api/dashboard');renderAll();if(DATA.sim_running) startAuto(); else stopAuto();}
function pct(v){return Math.max(0,Math.min(100,+v||0))}
function badge(text,cls=''){return `<span class="badge ${cls||String(text).toLowerCase().replaceAll(' ','-')}">${text}</span>`}
function renderAll(){
  $('simClock').textContent=`Digital twin time: ${new Date(DATA.sim_time).toLocaleString()} · Every simulation step updates cargo, inventory, assets and risk.`;
  $('runBtn').textContent=DATA.sim_running?'⏸ Pause Live':'▶ Run Live';
  const k=[['Personnel',DATA.counts.personnel,'Active expedition records'],['Cargo',DATA.counts.cargo,'Tracked cargo units'],['Assets',DATA.counts.assets,'Station equipment'],['Readiness',DATA.readiness.overall+'%','Calculated from live state'],['Alerts',DATA.counts.alerts,'Operational exceptions']];
  $('kpis').innerHTML=k.map((x,i)=>`<div class="kpi k${i}"><small>${x[0]}</small><strong>${x[1]}</strong><span>${x[2]}</span></div>`).join('');
  renderMap();renderReadiness();renderAlerts();renderRecommendations();renderMissions();renderCargo();renderInventory();renderAssets();renderEmergency();renderAudit();
}
function renderMap(){
  const s=DATA.shipments.find(x=>x.id==='SHP-001')||DATA.shipments[0]; const progress=pct(s.progress);
  const path=$('routeLine'); const pt=path.getPointAtLength(path.getTotalLength()*progress/100); $('shipMarker').setAttribute('transform',`translate(${pt.x},${pt.y})`);
  $('routeStatus').innerHTML=`<b>${s.id}</b> ${badge(s.status,s.status==='Delayed'?'high':'safe')}<br><span>${s.mode} · ${s.origin} → ${s.destination}</span><br><strong>${Math.round(progress)}%</strong> route completed · ETA ${(+s.eta_days).toFixed(1)} days ${s.weather_delay?`· ${s.weather_delay}d weather delay`:''}`;
}
function renderReadiness(){let r=DATA.readiness;let parts=[['Personnel',r.personnel],['Cargo',r.cargo],['Inventory',r.inventory],['Assets',r.assets],['Transport',r.transport]];$('readiness').innerHTML=`<div class="score"><div class="ring" style="--p:${r.overall}"><span>${r.overall}%</span></div><div><b>${r.overall>=85?'MISSION ON TRACK':r.overall>=70?'MISSION AT RISK':'MISSION CRITICAL'}</b><small>Calculated, not hard-coded</small></div></div>`+parts.map(x=>`<div class="metric"><span>${x[0]}</span><div><i style="width:${pct(x[1])}%"></i></div><b>${x[1]}%</b></div>`).join('')}
function renderAlerts(){
  $('alerts').innerHTML=DATA.alerts.length?DATA.alerts.slice(0,6).map(a=>`<div class="alert-row"><span class="dot ${a.severity.toLowerCase()}"></span><div><b>${a.type}</b><p>${a.message}</p></div>${badge(a.severity,a.severity.toLowerCase())}<button onclick="ackAlert(${a.id})">✓</button></div>`).join(''):'<div class="empty">No active alerts. The mission is operating normally.</div>';
}
function renderRecommendations(){
  let items=[];
  DATA.inventory.filter(x=>x.risk==='Critical').forEach(x=>items.push(`<b>Supply Risk:</b> ${x.item} at ${x.station} lasts ${x.days_remaining}d but resupply is ${x.resupply_days}d away. Consider transfer from another station or expedited air cargo.`));
  DATA.missions.filter(x=>x.status==='At Risk').forEach(x=>items.push(`<b>${x.id} At Risk:</b> Check delayed dependent cargo and alternative resources.`));
  DATA.work_orders.filter(x=>x.status!=='Closed').slice(0,2).forEach(x=>items.push(`<b>${x.asset_id} Maintenance:</b> ${x.reason}. ${x.plan}`));
  if(!items.length)items=['All tracked resources are within current operating thresholds. Continue live monitoring.'];
  $('recommendations').innerHTML=items.map((x,i)=>`<div class="rec"><span>${i+1}</span><p>${x}</p></div>`).join('');
}
function renderMissions(){$('missions').innerHTML=DATA.missions.map(m=>`<div class="card"><div class="card-head"><b>${m.id}</b>${badge(m.status,m.status==='At Risk'?'high':'safe')}</div><h3>${m.name}</h3><p>${m.station} · Priority ${m.priority}</p><small>Dependency engine updates this mission if linked cargo is delayed.</small></div>`).join('')}
function renderCargo(){
  $('cargoTable').innerHTML=`<thead><tr><th>ID</th><th>Cargo</th><th>Mission</th><th>Location</th><th>Status</th><th>Mode</th><th>Shipment</th><th>Chain</th></tr></thead><tbody>`+DATA.cargo.map(c=>`<tr><td><b>${c.id}</b></td><td>${c.name}<small>${c.weight}kg · ${c.quantity} ${c.unit}</small></td><td>${c.mission_id||'-'}</td><td>${c.location}</td><td>${badge(c.status,c.status==='Delayed'?'high':'')}</td><td>${badge(c.transport,c.transport==='AIR'?'blue':'')}</td><td>${c.shipment_id||'-'}</td><td><button onclick="cargoHistory('${c.id}')">History</button>${['PC-1024','PC-1088','PC-1121','PC-1180'].includes(c.id)?` <button onclick="showQR('${c.id}')">QR Label</button>`:''}</td></tr>`).join('')+'</tbody>';
}
function renderInventory(){
  $('inventoryCards').innerHTML=DATA.inventory.map(x=>`<div class="card"><div class="card-head"><b>${x.station}</b>${badge(x.risk,x.risk==='Critical'?'critical':x.risk==='Low'?'medium':'safe')}</div><h3>${x.item}</h3><div class="big-number">${(+x.qty).toFixed(1)} <small>${x.unit}</small></div><div class="forecast"><span>Daily usage <b>${x.daily_usage} ${x.unit}</b></span><span>Days remaining <b>${x.days_remaining}</b></span><span>Incoming resupply <b>${x.resupply_days==null?'No linked shipment':x.resupply_days+' days'}</b></span></div><div class="stockbar"><i style="width:${Math.min(100,100*x.qty/Math.max(x.reorder_threshold*3,1))}%"></i></div></div>`).join('')
}
function renderAssets(){
  $('assetCards').innerHTML=DATA.assets.map(a=>`<div class="card asset ${a.status==='Failed'?'failed':''}"><div class="card-head"><b>${a.id}</b>${badge(a.status,a.status==='Failed'?'critical':a.status==='Operational'?'safe':'medium')}</div><h3>${a.name}</h3><p>${a.location} · ${a.type}${a.is_backup?' · Backup':''}</p><div class="health"><span>Health <b>${(+a.health).toFixed(0)}%</b></span><div><i style="width:${pct(a.health)}%"></i></div></div><div class="runtime">Runtime <b>${(+a.runtime).toFixed(0)}h</b> / Service ${a.service_interval}h</div><small>Required spare: ${a.part_required||'N/A'}</small></div>`).join('');
  $('workOrders').innerHTML=DATA.work_orders.length?DATA.work_orders.map(w=>`<div class="wo"><b>WO-${String(w.id).padStart(4,'0')} · ${w.asset_id}</b>${badge(w.status,w.status==='Open'?'medium':'safe')}<p>${w.reason}</p><small>Technician: ${w.technician} · Part: ${w.part||'N/A'}</small><div>${w.plan}</div></div>`).join(''):'<div class="empty">No work orders generated.</div>'
}
function renderEmergency(){
  $('emergencies').innerHTML=DATA.emergencies.length?DATA.emergencies.map(e=>`<div class="incident"><b>INC-${String(e.id).padStart(3,'0')} · ${e.type}</b>${badge(e.status,'critical')}<p>${e.location} · ${e.person}</p><small>${e.ts}</small><div>${e.response_plan.replaceAll(' | ',' → ')}</div></div>`).join(''):'<div class="empty">No incident has been created.</div>'
}
function renderAudit(){
  $('auditAlerts').innerHTML=DATA.alerts.length?DATA.alerts.map(a=>`<div class="log-row"><span>${a.ts.slice(11,19)}</span><b>${a.severity}</b><p>${a.message}</p><button onclick="ackAlert(${a.id})">Acknowledge</button></div>`).join(''):'<div class="empty">No active alerts.</div>';
  $('auditLog').innerHTML=DATA.audit.length?DATA.audit.map(a=>`<div class="log-row"><span>${a.ts.replace('T',' ')}</span><b>${a.actor}</b><p>${a.action} · ${a.entity} ${a.entity_id}<small>${a.details}</small></p></div>`).join(''):'<div class="empty">No audit entries.</div>'
}
async function advance(hours){await api('/api/sim/advance','POST',{hours});await refresh()}
async function toggleRun(){if(DATA.sim_running){await api('/api/sim/pause','POST');stopAuto()}else{await api('/api/sim/run','POST');startAuto()}await refresh()}
function startAuto(){if(runTimer)return;runTimer=setInterval(async()=>{try{await api('/api/sim/advance','POST',{hours:6});await refresh()}catch(e){}},4000)}
function stopAuto(){if(runTimer){clearInterval(runTimer);runTimer=null}}
async function weather(){await api('/api/sim/weather','POST');await refresh();toast('Weather delay injected: ETA, cargo and risk recalculated.')}
async function clearWeather(){await api('/api/sim/clear-weather','POST');await refresh();toast('Transit resumed. Existing delay remains reflected in ETA.')}
async function failAsset(id){let j=await api('/api/sim/fail-asset','POST',{asset_id:id});await refresh();showView('assets');alert('Response plan:\n\n'+j.plan.join('\n'))}
async function createEmergency(){let j=await api('/api/sim/emergency','POST',{type:$('emType').value,location:$('emLoc').value,person:$('emPerson').value});$('emPlan').innerHTML=`<div class="response-plan"><h3>Generated Response Plan</h3>${j.plan.map((x,i)=>`<div><span>${i+1}</span>${x}</div>`).join('')}</div>`;await refresh()}
async function scanCargo(){try{let j=await api('/api/cargo/scan','POST',{cargo_id:$('scanId').value.trim(),location:$('scanLocation').value,note:'Operational handover scan'});$('scanResult').innerHTML=`<div class="success">${j.cargo.id} updated → ${j.cargo.status} at ${j.cargo.location}. Database transaction recorded.</div>`;await refresh()}catch(e){$('scanResult').innerHTML=`<div class="error">${e.message}</div>`}}
async function cargoHistory(id){let h=await api(`/api/cargo/${id}/history`);alert(id+' chain-of-custody:\n\n'+h.map(x=>`${x.ts} | ${x.location} | ${x.status} | ${x.actor}`).join('\n'))}
function showQR(id){window.open('/static/qr/'+id+'.png','qr','width=360,height=420')}
function openCargoForm(){$('cargoModal').classList.remove('hidden');previewCargoTransport()}function closeCargoForm(){$('cargoModal').classList.add('hidden')}
async function previewCargoTransport(){let j=await api('/api/transport/recommend','POST',{weight:$('cgWeight').value,priority:$('cgPriority').value,category:$('cgCategory').value});$('cgRecommend').innerHTML=`Recommended transport: <b>${j.mode}</b><br>${j.reason}`}
async function createCargo(){try{let j=await api('/api/cargo/add','POST',{name:$('cgName').value,category:$('cgCategory').value,weight:$('cgWeight').value,quantity:$('cgQty').value,unit:$('cgUnit').value,priority:$('cgPriority').value,origin:$('cgOrigin').value,destination:$('cgDestination').value,mission_id:$('cgMission').value,container_id:$('cgContainer').value,inventory_item:$('cgInventory').value});closeCargoForm();await refresh();showView('cargo');toast(`${j.cargo_id} created and assigned to ${j.transport}.`) }catch(e){alert(e.message)}}
async function recommendTransport(){let j=await api('/api/transport/recommend','POST',{weight:$('trWeight').value,priority:$('trPriority').value,category:$('trCategory').value});$('transportResult').innerHTML=`<div class="callout"><b>${j.mode}</b> — ${j.reason}</div>`}
async function ackAlert(id){await api('/api/alerts/ack','POST',{id});await refresh()}
async function resetDemo(){if(!confirm('Reset all simulation data to the original SIH demo state?'))return;await api('/api/reset','POST');await refresh();toast('Demo database reset.')}
function downloadManifest(){location.href='/api/manifest.csv'}
function toast(t){let d=document.createElement('div');d.className='toast';d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),3200)}
async function startCameraScan(){
  if(!('BarcodeDetector' in window)){alert('This browser does not expose BarcodeDetector. Use manual cargo ID entry for the demo, or open Chrome/Edge with QR support.');return}
  try{const det=new BarcodeDetector({formats:['qr_code']});const v=$('scanVideo');v.classList.remove('hidden');const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}});v.srcObject=stream;let tries=0;const timer=setInterval(async()=>{tries++;try{const codes=await det.detect(v);if(codes.length){$('scanId').value=codes[0].rawValue;clearInterval(timer);stream.getTracks().forEach(t=>t.stop());v.classList.add('hidden');toast('QR read: '+codes[0].rawValue)}}catch(e){}if(tries>100){clearInterval(timer);stream.getTracks().forEach(t=>t.stop());v.classList.add('hidden')}},300)}catch(e){alert('Camera QR scan unavailable: '+e.message)}
}
init();
